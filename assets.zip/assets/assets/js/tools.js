// 工具数据管理和搜索功能
// 负责工具数据的加载、管理、搜索和分类

export class ToolManager {
    constructor() {
        // 工具列表
        this.tools = [];
        // 按分类索引的工具
        this.categories = {};
        // 初始化
        this.init();
    }

    /**
     * 初始化工具管理器
     * 加载工具数据并构建分类索引
     */
    async init() {
        // 加载工具数据
        await this.loadToolData();
        // 构建分类索引
        this.buildCategoryIndex();
    }

    /**
     * 加载工具数据
     * 从JSON文件加载，如果失败则使用默认工具数据
     */
    async loadToolData() {
        try {
            console.log('开始加载工具数据');
            // 从JSON文件或API加载工具数据
            const response = await fetch('data/tools.json');
            console.log('数据请求状态:', response.status);
            
            if (!response.ok) {
                throw new Error(`HTTP错误: ${response.status}`);
            }
            
            const data = await response.json();
            console.log('数据加载成功:', data);
            
            // 提取工具列表
            this.tools = data.tools || [];
            console.log('工具列表:', this.tools);
        } catch (error) {
            console.error('加载工具数据失败:', error);
            // 使用默认工具数据
            console.log('使用默认工具数据');
            this.tools = this.getDefaultTools();
            console.log('默认工具数据:', this.tools);
        }
    }

    /**
     * 获取默认工具数据
     * 当加载失败时使用
     * @returns {Array} 默认工具列表
     */
    getDefaultTools() {
        return [
            {
                id: 'json-formatter',
                name: 'JSON格式化',
                description: '美化和格式化JSON数据，支持语法验证',
                category: 'text',
                icon: 'fas fa-code',
                popular: true,
                featured: true,
                tags: ['json', '格式化', '开发']
            },
            {
                id: 'qrcode-generator',
                name: '二维码生成器',
                description: '生成自定义样式二维码，支持LOGO',
                category: 'image',
                icon: 'fas fa-qrcode',
                popular: true,
                featured: true,
                tags: ['二维码', '生成', '图片']
            },
            // ... 更多工具数据
            // 如需添加默认工具，请在此处添加
        ];
    }

    /**
     * 构建分类索引
     * 将工具按分类分组
     */
    buildCategoryIndex() {
        this.categories = this.tools.reduce((acc, tool) => {
            if (!acc[tool.category]) {
                acc[tool.category] = [];
            }
            acc[tool.category].push(tool);
            return acc;
        }, {});
    }

    /**
     * 获取所有工具
     * @returns {Promise<Array>} 工具列表
     */
    async getTools() {
        console.log('获取工具数据:', this.tools);
        
        // 确保工具数据已加载
        if (this.tools.length === 0) {
            console.log('工具数据为空，重新加载');
            await this.loadToolData();
            this.buildCategoryIndex();
        }
        
        console.log('返回工具数据:', this.tools);
        return this.tools;
    }

    /**
     * 根据ID获取工具
     * @param {string} id - 工具ID
     * @returns {Object|null} 工具对象
     */
    getTool(id) {
        return this.tools.find(tool => tool.id === id);
    }

    /**
     * 根据分类获取工具
     * @param {string} category - 分类ID
     * @returns {Array} 分类工具列表
     */
    getToolsByCategory(category) {
        return this.categories[category] || [];
    }

    /**
     * 搜索工具
     * @param {string} query - 搜索关键词
     * @returns {Promise<Array>} 搜索结果
     */
    async searchTools(query) {
        const searchTerms = query.toLowerCase().split(' ');
        
        return this.tools.filter(tool => {
            const searchableText = `
                ${tool.name} 
                ${tool.description} 
                ${tool.tags?.join(' ') || ''}
            `.toLowerCase();
            
            // 检查所有搜索词是否都在可搜索文本中
            return searchTerms.every(term => searchableText.includes(term));
        });
    }

    /**
     * 获取热门工具
     * @param {number} limit - 限制数量
     * @returns {Array} 热门工具列表
     */
    getPopularTools(limit = 10) {
        return this.tools
            .filter(tool => tool.popular)
            .sort((a, b) => (b.usageCount || 0) - (a.usageCount || 0))
            .slice(0, limit);
    }

    /**
     * 获取最近添加的工具
     * @returns {Array} 最近工具列表
     */
    getRecentTools() {
        return this.tools
            .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
            .slice(0, 5);
    }
}

// 单个工具的功能实现
// 负责工具的具体执行逻辑
export class Tool {
    /**
     * 构造函数
     * @param {string} id - 工具ID
     * @param {Object} config - 工具配置
     */
    constructor(id, config) {
        this.id = id;
        this.config = config;
    }

    /**
     * 执行工具
     * 根据工具类型执行不同的处理逻辑
     * @param {*} input - 输入数据
     * @param {Object} options - 执行选项
     * @returns {Promise<*>} 执行结果
     */
    async execute(input, options = {}) {
        // 根据工具类型执行不同的处理逻辑
        switch (this.config.type) {
            case 'text':
                return this.processText(input, options);
            case 'image':
                return this.processImage(input, options);
            case 'converter':
                return this.convertData(input, options);
            default:
                throw new Error('未知的工具类型');
        }
    }

    /**
     * 处理文本
     * 文本处理工具的实现
     * @param {string} input - 输入文本
     * @param {Object} options - 处理选项
     * @returns {string} 处理结果
     */
    processText(input, options) {
        // 文本处理工具的实现
        const processors = {
            'json-formatter': this.formatJSON.bind(this),
            'text-case': this.changeTextCase.bind(this),
            // ... 其他文本处理函数
            // 如需添加更多文本处理工具，请在此处添加
        };

        const processor = processors[this.id];
        return processor ? processor(input, options) : input;
    }

    /**
     * 格式化JSON
     * @param {string} input - JSON字符串
     * @param {Object} options - 格式化选项
     * @returns {string} 格式化后的JSON
     */
    formatJSON(input, options) {
        try {
            const obj = JSON.parse(input);
            return JSON.stringify(obj, null, options.indent || 2);
        } catch (error) {
            throw new Error('无效的JSON格式');
        }
    }

    /**
     * 改变文本大小写
     * @param {string} input - 输入文本
     * @param {Object} options - 处理选项
     * @returns {string} 处理后的文本
     */
    changeTextCase(input, options) {
        const { case: textCase } = options;
        
        switch (textCase) {
            case 'upper':
                return input.toUpperCase();
            case 'lower':
                return input.toLowerCase();
            case 'title':
                return input.replace(/\b\w/g, char => char.toUpperCase());
            default:
                return input;
        }
    }

    /**
     * 处理图像
     * 图像处理工具的方法
     * @param {*} imageData - 图像数据
     * @param {Object} options - 处理选项
     * @returns {Promise<Object>} 处理结果
     */
    processImage(imageData, options) {
        // 实现图像处理逻辑
        return new Promise((resolve) => {
            // 模拟图像处理
            setTimeout(() => {
                resolve({
                    success: true,
                    data: imageData,
                    format: options.format || 'png'
                });
            }, 100);
        });
    }

    /**
     * 转换数据
     * 数据转换工具的方法
     * @param {*} input - 输入数据
     * @param {Object} options - 转换选项
     * @returns {*} 转换结果
     */
    convertData(input, options) {
        // 数据转换工具的实现
        // 如需添加数据转换工具，请在此处实现
        return input;
    }
}