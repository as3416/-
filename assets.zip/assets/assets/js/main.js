// 主应用逻辑
// 负责整个应用的初始化、数据加载、UI渲染和事件绑定
import { loadComponent } from './ui.js';
import { ToolManager } from './tools.js';
import { StorageManager } from './storage.js';

class EaseToolsApp {
    constructor() {
        // 初始化工具管理器，负责工具数据的加载和管理
        this.toolManager = new ToolManager();
        // 初始化存储管理器，负责本地存储的操作（历史记录、收藏等）
        this.storage = new StorageManager();
        // 当前视图模式（网格/列表）
        this.currentView = 'grid';
        // 初始化应用
        this.init();
    }

    /**
     * 初始化应用
     * 按顺序执行：加载组件 → 初始化UI → 加载工具数据 → 绑定事件 → 检查主题
     */
    async init() {
        // 记录每日活动
        this.storage.trackDailyActivity();
        
        // 记录用户活动
        this.trackUserActivity('page_view', { page: 'home' });
        
        // 加载组件
        await this.loadComponents();
        
        // 初始化UI
        this.initUI();
        
        // 加载工具数据
        await this.loadTools();
        
        // 绑定事件
        this.bindEvents();
        
        // 检查主题
        this.checkTheme();
    }

    /**
     * 加载页面组件
     * 目前加载：头部和页脚
     */
    async loadComponents() {
        // 加载头部和页脚
        await Promise.all([
            loadComponent('components/header.html', 'header-container'),
            loadComponent('components/footer.html', 'footer-container')
        ]);
        // 如需加载更多组件，请在此处添加
    }

    /**
     * 加载工具数据并渲染页面
     */
    async loadTools() {
        // 获取所有工具数据
        const tools = await this.toolManager.getTools();
        // 渲染工具分类
        this.renderCategories(tools);
        // 渲染特色工具
        this.renderFeaturedTools(tools);
        // 渲染推荐工具
        this.renderRecommendedTools();
    }

    /**
     * 渲染工具分类
     * @param {Array} tools - 工具列表
     */
    renderCategories(tools) {
        const container = document.getElementById('categories-container');
        if (!container) {
            console.error('分类容器不存在');
            return;
        }

        console.log('工具数据:', tools);
        
        // 按分类分组工具
        const categories = this.groupToolsByCategory(tools);
        
        console.log('分组后的分类:', categories);
        
        if (Object.keys(categories).length === 0) {
            console.error('没有分类数据');
            container.innerHTML = '<p style="text-align: center; color: #666; padding: 40px;">暂无工具分类数据</p>';
            return;
        }
        
        // 生成分类卡片HTML
        container.innerHTML = Object.entries(categories).map(([category, items]) => `
            <div class="category-card" data-category="${category}">
                <div class="category-icon">
                    <i class="${this.getCategoryIcon(category)}"></i>
                </div>
                <h3>${this.getCategoryName(category)}</h3>
                <p>${items.length}款工具，覆盖各种使用场景</p>
                <div class="category-stats">
                    <span>${this.getPopularToolsCount(items)}个热门工具</span>
                    <span><i class="fas fa-arrow-right"></i></span>
                </div>
            </div>
        `).join('');
        
        // 为每个分类卡片添加点击事件监听器
        const categoryCards = container.querySelectorAll('.category-card');
        categoryCards.forEach(card => {
            card.addEventListener('click', () => {
                const category = card.dataset.category;
                console.log('点击分类:', category);
                this.openCategory(category);
            });
        });
        
        // 如需修改分类卡片的样式或内容，请修改上面的HTML模板
    }

    /**
     * 渲染特色工具
     * @param {Array} tools - 工具列表
     */
    renderFeaturedTools(tools) {
        const container = document.getElementById('featured-tools');
        if (!container) return;

        // 筛选出特色工具（featured: true）并限制显示10个
        const featured = tools.filter(tool => tool.featured).slice(0, 10);
        
        // 生成特色工具卡片HTML
        container.innerHTML = featured.map(tool => `
            <div class="featured-tool">
                <span class="featured-badge">特色工具</span>
                <div class="featured-icon">
                    <i class="${tool.icon}"></i>
                </div>
                <h3>${tool.name}</h3>
                <p>${tool.description}</p>
                <ul class="feature-list">
                    <li>完全本地处理，数据安全</li>
                    <li>支持批量操作</li>
                    <li>实时预览效果</li>
                    <li>多种格式导出</li>
                    <!-- 如需添加更多特色说明，请在此处添加 -->
                </ul>
                <button class="use-btn" data-tool="${tool.id}">立即使用</button>
            </div>
        `).join('');
        
        // 如需修改特色工具卡片的样式或内容，请修改上面的HTML模板
    }

    /**
     * 渲染推荐工具
     * 基于用户的使用历史和收藏
     */
    renderRecommendedTools() {
        const container = document.getElementById('recommended-tools');
        if (!container) return;

        // 获取最近使用的工具
        const recent = this.storage.getRecentTools();
        // 获取收藏的工具
        const favorites = this.storage.getFavorites();
        
        // 合并并去重，取前2个最近使用和前2个收藏的工具
        const recommended = [...new Set([...recent.slice(0, 2), ...favorites.slice(0, 2)])];
        
        if (recommended.length > 0) {
            // 显示推荐工具
            container.innerHTML = `
                <div class="tools-grid">
                    ${recommended.map(toolId => {
                        const tool = this.toolManager.getTool(toolId);
                        if (!tool) return '';
                        return `
                            <div class="tool-card">
                                <div class="tool-header">
                                    <div class="tool-icon-small">
                                        <i class="${tool.icon}"></i>
                                    </div>
                                    <div class="tool-actions">
                                        <button class="favorite-btn ${favorites.includes(toolId) ? 'active' : ''}" 
                                                data-tool="${toolId}">
                                            <i class="fas fa-star"></i>
                                        </button>
                                    </div>
                                </div>
                                <h4>${tool.name}</h4>
                                <p class="tool-description">${tool.description}</p>
                                <button class="use-btn" data-tool="${tool.id}">使用工具</button>
                            </div>
                        `;
                    }).join('')}
                </div>
            `;
        } else {
            // 显示默认推荐
            container.innerHTML = `
                <div class="default-recommendation">
                    <p>开始使用工具，系统会根据您的使用习惯进行智能推荐</p>
                </div>
            `;
        }
    }

    /**
     * 初始化UI交互
     */
    initUI() {
        // 初始化搜索
        const searchInput = document.getElementById('tool-search');
        if (searchInput) {
            searchInput.addEventListener('input', this.handleSearch.bind(this));
        }

        // 初始化视图切换
        const viewButtons = document.querySelectorAll('.view-btn');
        viewButtons.forEach(btn => {
            btn.addEventListener('click', () => this.toggleView(btn.dataset.view));
        });

        // 初始化工具卡片点击
        document.addEventListener('click', (e) => {
            // 处理使用工具按钮点击
            const useBtn = e.target.closest('.use-btn');
            if (useBtn) {
                const toolId = useBtn.dataset.tool;
                this.openTool(toolId);
            }

            // 处理分类卡片点击
            const categoryCard = e.target.closest('.category-card');
            if (categoryCard) {
                const category = categoryCard.dataset.category;
                this.openCategory(category);
            }
        });
    }

    /**
     * 绑定其他事件
     */
    bindEvents() {
        // 搜索功能
        const searchBox = document.querySelector('.search-box');
        if (searchBox) {
            searchBox.addEventListener('submit', (e) => {
                e.preventDefault();
                this.performSearch();
            });
        }

        // 收藏功能
        document.addEventListener('click', (e) => {
            const favoriteBtn = e.target.closest('.favorite-btn');
            if (favoriteBtn) {
                const toolId = favoriteBtn.dataset.tool;
                this.toggleFavorite(toolId, favoriteBtn);
            }
        });

        // 主题切换
        const themeToggle = document.querySelector('.theme-toggle');
        if (themeToggle) {
            themeToggle.addEventListener('click', () => this.toggleTheme());
        }
    }

    /**
     * 处理搜索输入
     * @param {Event} event - 输入事件
     */
    handleSearch(event) {
        const query = event.target.value.toLowerCase();
        if (query.length > 2) {
            this.performSearch(query);
        }
    }

    /**
     * 执行搜索
     * @param {string} query - 搜索关键词
     */
    async performSearch(query = '') {
        if (!query) {
            query = document.getElementById('tool-search').value;
        }

        if (query.trim() === '') return;

        // 搜索工具
        const results = await this.toolManager.searchTools(query);
        // 显示搜索结果
        this.displaySearchResults(results);
    }

    /**
     * 显示搜索结果
     * @param {Array} results - 搜索结果
     */
    displaySearchResults(results) {
        // 实现搜索结果展示
        // 如需添加搜索结果页面，请在此处实现
        console.log('搜索结果:', results);
    }

    /**
     * 切换视图模式（网格/列表）
     * @param {string} view - 视图模式 ('grid' 或 'list')
     */
    toggleView(view) {
        this.currentView = view;
        const container = document.querySelector('.tools-grid') || document.querySelector('.categories-container');
        
        if (container) {
            container.classList.remove('grid-view', 'list-view');
            container.classList.add(`${view}-view`);
        }

        // 更新按钮状态
        document.querySelectorAll('.view-btn').forEach(btn => {
            btn.classList.toggle('active', btn.dataset.view === view);
        });
    }

    /**
     * 打开工具页面
     * @param {string} toolId - 工具ID
     */
    openTool(toolId) {
        // 记录使用历史
        this.storage.addRecentTool(toolId);
        
        // 记录工具使用统计
        this.storage.trackToolUsage(toolId);
        
        // 记录用户活动
        this.trackUserActivity('tool_used', { toolId });
        
        // 跳转到工具页面
        // 注意：实际项目中需要创建对应的工具页面
        window.location.href = `/tools/${toolId}.html`;
    }

    /**
     * 打开分类页面
     * @param {string} category - 分类ID
     */
    openCategory(category) {
        // 记录分类浏览历史
        this.storage.addCategoryHistory(category);
        
        // 跳转到分类详情页面
        window.location.href = `category-detail.html?category=${encodeURIComponent(category)}`;
    }
    /**
     * 切换收藏状态
     * @param {string} toolId - 工具ID
     * @param {Element} button - 收藏按钮元素
     */
    toggleFavorite(toolId, button) {
        // 切换收藏状态
        const isFavorite = this.storage.toggleFavorite(toolId);
        // 更新按钮样式
        button.classList.toggle('active', isFavorite);
        button.querySelector('i').classList.toggle('fas', isFavorite);
        button.querySelector('i').classList.toggle('far', !isFavorite);
    }

    /**
     * 检查并设置主题
     */
    checkTheme() {
        const savedTheme = localStorage.getItem('theme') || 'light';
        document.documentElement.setAttribute('data-theme', savedTheme);
    }

    /**
     * 记录用户活动
     * @param {string} type - 活动类型
     * @param {Object} data - 活动数据
     */
    trackUserActivity(type, data = {}) {
        const activity = {
            type,
            data,
            timestamp: new Date().toISOString(),
            userAgent: navigator.userAgent,
            screenSize: `${window.screen.width}x${window.screen.height}`
        };
        
        this.storage.addUserActivity(activity);
    }

    /**
     * 切换主题（浅色/深色）
     */
    toggleTheme() {
        const currentTheme = document.documentElement.getAttribute('data-theme');
        const newTheme = currentTheme === 'light' ? 'dark' : 'light';
        
        document.documentElement.setAttribute('data-theme', newTheme);
        localStorage.setItem('theme', newTheme);
    }

    /**
     * 按分类分组工具
     * @param {Array} tools - 工具列表
     * @returns {Object} - 按分类分组的工具
     */
    groupToolsByCategory(tools) {
        return tools.reduce((acc, tool) => {
            if (!acc[tool.category]) {
                acc[tool.category] = [];
            }
            acc[tool.category].push(tool);
            return acc;
        }, {});
    }

    /**
     * 获取分类图标
     * @param {string} category - 分类ID
     * @returns {string} - 图标类名
     */
    getCategoryIcon(category) {
        const icons = {
            'text': 'fas fa-font',
            'image': 'fas fa-image',
            'encode': 'fas fa-code',
            'developer': 'fas fa-laptop-code',
            'life': 'fas fa-home',
            'office': 'fas fa-file-alt',
            'finance': 'fas fa-chart-line',
            'health': 'fas fa-heartbeat'
            // 如需添加更多分类图标，请在此处添加
        };
        return icons[category] || 'fas fa-tools';
    }

    /**
     * 获取分类名称
     * @param {string} category - 分类ID
     * @returns {string} - 分类名称
     */
    getCategoryName(category) {
        const names = {
            'text': '文本处理',
            'image': '图像工具',
            'encode': '编码转换',
            'developer': '开发工具',
            'life': '生活实用',
            'office': '办公效率',
            'finance': '金融计算',
            'health': '健康计算'
            // 如需添加更多分类名称，请在此处添加
        };
        return names[category] || '其他工具';
    }

    /**
     * 获取热门工具数量
     * @param {Array} tools - 工具列表
     * @returns {number} - 热门工具数量
     */
    getPopularToolsCount(tools) {
        return tools.filter(tool => tool.popular).length;
    }
}

// 初始化应用
document.addEventListener('DOMContentLoaded', () => {
    const app = new EaseToolsApp();
    window.EaseToolsApp = app; // 全局访问
});

// 工具函数

/**
 * 格式化数字（添加千位分隔符）
 * @param {number} num - 数字
 * @returns {string} - 格式化后的数字
 */
export function formatNumber(num) {
    return num.toLocaleString();
}

/**
 * 防抖函数
 * @param {Function} func - 要执行的函数
 * @param {number} wait - 等待时间（毫秒）
 * @returns {Function} - 防抖后的函数
 */
export function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}