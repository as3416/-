// 本地存储管理
export class StorageManager {
    constructor() {
        this.prefix = 'easertools_';
        this.init();
    }

    init() {
        // 初始化存储结构
        if (!this.get('favorites')) {
            this.set('favorites', []);
        }
        if (!this.get('recent_tools')) {
            this.set('recent_tools', []);
        }
        if (!this.get('settings')) {
            this.set('settings', {
                theme: 'light',
                view_mode: 'grid',
                search_history: []
            });
        }
    }

    // 基础存储方法
    set(key, value) {
        const storageKey = this.prefix + key;
        try {
            localStorage.setItem(storageKey, JSON.stringify(value));
            return true;
        } catch (error) {
            console.error('存储数据失败:', error);
            return false;
        }
    }

    get(key, defaultValue = null) {
        const storageKey = this.prefix + key;
        try {
            const item = localStorage.getItem(storageKey);
            return item ? JSON.parse(item) : defaultValue;
        } catch (error) {
            console.error('读取数据失败:', error);
            return defaultValue;
        }
    }

    remove(key) {
        const storageKey = this.prefix + key;
        localStorage.removeItem(storageKey);
    }

    clear() {
        // 只清除当前应用的数据
        Object.keys(localStorage).forEach(key => {
            if (key.startsWith(this.prefix)) {
                localStorage.removeItem(key);
            }
        });
    }

    // 工具相关的方法
    addRecentTool(toolId) {
        const recent = this.get('recent_tools', []);
        
        // 移除已存在的记录
        const filtered = recent.filter(id => id !== toolId);
        
        // 添加到开头
        filtered.unshift(toolId);
        
        // 限制最多10个
        const updated = filtered.slice(0, 10);
        
        this.set('recent_tools', updated);
        return updated;
    }

    getRecentTools() {
        return this.get('recent_tools', []);
    }

    toggleFavorite(toolId) {
        const favorites = this.get('favorites', []);
        const index = favorites.indexOf(toolId);
        
        if (index > -1) {
            // 已收藏，移除
            favorites.splice(index, 1);
            this.set('favorites', favorites);
            return false;
        } else {
            // 未收藏，添加
            favorites.push(toolId);
            this.set('favorites', favorites);
            return true;
        }
    }

    getFavorites() {
        return this.get('favorites', []);
    }

    isFavorite(toolId) {
        const favorites = this.getFavorites();
        return favorites.includes(toolId);
    }

    // 设置管理
    updateSettings(newSettings) {
        const current = this.get('settings', {});
        const updated = { ...current, ...newSettings };
        this.set('settings', updated);
        return updated;
    }

    getSetting(key, defaultValue = null) {
        const settings = this.get('settings', {});
        return settings[key] !== undefined ? settings[key] : defaultValue;
    }

    // 搜索历史
    addSearchHistory(query) {
        if (!query.trim()) return;
        
        const history = this.get('search_history', []);
        const filtered = history.filter(item => item.toLowerCase() !== query.toLowerCase());
        filtered.unshift(query);
        
        // 限制最多20条
        const updated = filtered.slice(0, 20);
        this.set('search_history', updated);
        
        return updated;
    }

    getSearchHistory() {
        return this.get('search_history', []);
    }

    clearSearchHistory() {
        this.set('search_history', []);
        return [];
    }

    // 使用统计
    trackToolUsage(toolId) {
        const stats = this.get('usage_stats', {});
        const toolStats = stats[toolId] || { count: 0, last_used: null };
        
        toolStats.count += 1;
        toolStats.last_used = new Date().toISOString();
        
        stats[toolId] = toolStats;
        this.set('usage_stats', stats);
        
        return toolStats;
    }

    getToolStats(toolId) {
        const stats = this.get('usage_stats', {});
        return stats[toolId] || { count: 0, last_used: null };
    }

    getMostUsedTools(limit = 5) {
        const stats = this.get('usage_stats', {});
        
        return Object.entries(stats)
            .sort(([, a], [, b]) => b.count - a.count)
            .slice(0, limit)
            .map(([toolId, stat]) => ({ toolId, ...stat }));
    }

    // 导出/导入数据
    exportData() {
        const data = {};
        Object.keys(localStorage).forEach(key => {
            if (key.startsWith(this.prefix)) {
                const cleanKey = key.replace(this.prefix, '');
                try {
                    data[cleanKey] = JSON.parse(localStorage.getItem(key));
                } catch {
                    data[cleanKey] = localStorage.getItem(key);
                }
            }
        });
        return data;
    }

    importData(data) {
        try {
            Object.entries(data).forEach(([key, value]) => {
                this.set(key, value);
            });
            return true;
        } catch (error) {
            console.error('导入数据失败:', error);
            return false;
        }
    }

    // 数据大小计算
    getStorageSize() {
        let total = 0;
        Object.keys(localStorage).forEach(key => {
            if (key.startsWith(this.prefix)) {
                total += (localStorage[key].length * 2) / 1024; // KB
            }
        });
        return total.toFixed(2);
    }
    
    // 分类浏览历史
    addCategoryHistory(category) {
        const history = this.get('category_history', []);
        
        // 移除已存在的记录
        const filtered = history.filter(cat => cat !== category);
        
        // 添加到开头
        filtered.unshift(category);
        
        // 限制最多10个
        const updated = filtered.slice(0, 10);
        
        this.set('category_history', updated);
        return updated;
    }
    
    getCategoryHistory() {
        return this.get('category_history', []);
    }
    
    // 用户活动记录
    addUserActivity(activity) {
        const activities = this.get('user_activities', []);
        
        // 添加到开头
        activities.unshift(activity);
        
        // 限制最多1000条记录
        const updated = activities.slice(0, 1000);
        
        this.set('user_activities', updated);
        return updated;
    }
    
    getUserActivities(limit = 100) {
        const activities = this.get('user_activities', []);
        return activities.slice(0, limit);
    }
    
    // 每日统计
    trackDailyActivity() {
        const today = new Date().toISOString().split('T')[0];
        const dailyStats = this.get('daily_stats', {});
        
        if (!dailyStats[today]) {
            dailyStats[today] = {
                visits: 0,
                toolsUsed: 0,
                uniqueTools: new Set(),
                categoriesViewed: 0,
                uniqueCategories: new Set()
            };
        }
        
        dailyStats[today].visits += 1;
        
        // 保存时转换Set为数组
        const savedStats = { ...dailyStats };
        Object.keys(savedStats).forEach(date => {
            if (savedStats[date].uniqueTools) {
                savedStats[date].uniqueTools = Array.from(savedStats[date].uniqueTools);
            }
            if (savedStats[date].uniqueCategories) {
                savedStats[date].uniqueCategories = Array.from(savedStats[date].uniqueCategories);
            }
        });
        
        this.set('daily_stats', savedStats);
        return savedStats[today];
    }
    
    getDailyStats(date = null) {
        const dailyStats = this.get('daily_stats', {});
        if (date) {
            return dailyStats[date] || null;
        }
        return dailyStats;
    }
}