// ==================== 权限控制 ====================
// （已在HTML中实现）

// ==================== 管理后台主逻辑 ====================
class AdminDashboard {
    constructor() {
        this.tools = [];
        this.categories = {};
        this.charts = {};
        this.currentToolId = null;
        this.currentCategoryId = null;
        this.currentCategoryFilter = null;
        this.init();
    }

    async init() {
        console.log('管理后台初始化...');
        
        // 设置当前日期
        this.setCurrentDate();
        
        // 加载工具数据
        await this.loadTools();
        
        // 初始化UI
        this.initUI();
        
        // 初始化图表
        this.initCharts();
        
        // 初始化使用分析图表
        this.initAnalyticsCharts();
        
        // 渲染分类
        this.renderCategories();
        
        // 绑定事件
        this.bindEvents();
        
        console.log('管理后台初始化完成');
    }

    setCurrentDate() {
        const now = new Date();
        const dateStr = now.toISOString().split('T')[0];
        document.getElementById('current-date').textContent = dateStr;
    }

    async loadTools() {
        try {
            const response = await fetch('../data/tools.json');
            if (!response.ok) throw new Error(`HTTP ${response.status}`);
            
            const data = await response.json();
            
            this.tools = data.tools || [];
            this.categories = data.categories || {};
            
            console.log(`加载了 ${this.tools.length} 个工具`);
            console.log(`加载了 ${Object.keys(this.categories).length} 个分类`);
            
            // 更新统计
            this.updateStats();
            
            // 渲染工具表格
            this.renderToolsTable();
            
        } catch (error) {
            console.error('加载工具数据失败:', error);
            this.loadDemoTools();
        }
    }

    loadDemoTools() {
        // 演示数据
        this.tools = [
            {
                id: 'json-formatter',
                name: 'JSON格式化',
                description: '美化和格式化JSON数据',
                category: 'text',
                icon: 'fas fa-code',
                popular: true,
                featured: true,
                localOnly: true,
                usageCount: 12500,
                page: '/tools/json-formatter.html',
                order: 1
            },
            {
                id: 'qrcode-generator',
                name: '二维码生成器',
                description: '生成自定义二维码',
                category: 'image',
                icon: 'fas fa-qrcode',
                popular: true,
                featured: true,
                localOnly: true,
                usageCount: 9800,
                page: '/tools/qrcode-generator.html',
                order: 2
            },
            {
                id: 'base64-encoder',
                name: 'Base64编码解码',
                description: '文本图片Base64互转',
                category: 'encode',
                icon: 'fas fa-exchange-alt',
                popular: true,
                featured: false,
                localOnly: true,
                usageCount: 7500,
                page: '/tools/base64-encoder.html',
                order: 3
            },
            {
                id: 'color-picker',
                name: '颜色选择器',
                description: '智能取色调色工具',
                category: 'image',
                icon: 'fas fa-palette',
                popular: true,
                featured: false,
                localOnly: true,
                usageCount: 6200,
                page: '/tools/color-picker.html',
                order: 4
            }
        ];
        
        this.categories = {
            'text': '文本处理',
            'image': '图像工具',
            'encode': '编码转换',
            'developer': '开发工具',
            'life': '生活实用',
            'office': '办公效率'
        };
        
        this.updateStats();
        this.renderToolsTable();
    }

    updateStats() {
        // 更新统计卡片
        document.getElementById('total-tools').textContent = this.tools.length;
        
        // 从localStorage获取真实的使用数据
        let totalUsage = 0;
        let uniqueUsers = 0;
        let todayUsage = 0;
        
        try {
            // 获取本地存储的使用统计
            const usageStats = JSON.parse(localStorage.getItem('easertools_usage_stats') || '{}');
            const dailyStats = JSON.parse(localStorage.getItem('easertools_daily_stats') || '{}');
            const userActivities = JSON.parse(localStorage.getItem('easertools_user_activities') || '[]');
            
            // 计算总使用次数
            Object.values(usageStats).forEach(stat => {
                totalUsage += stat.count || 0;
            });
            
            // 计算今日使用次数
            const today = new Date().toISOString().split('T')[0];
            if (dailyStats[today]) {
                todayUsage = dailyStats[today].toolsUsed || 0;
            }
            
            // 计算活跃用户数（基于活动记录）
            const uniqueUserAgents = new Set();
            userActivities.forEach(activity => {
                if (activity.userAgent) {
                    uniqueUserAgents.add(activity.userAgent.substring(0, 100)); // 取前100字符作为用户标识
                }
            });
            uniqueUsers = uniqueUserAgents.size;
            
        } catch (error) {
            console.error('读取统计数据失败:', error);
            // 回退到基于工具数据的计算
            totalUsage = this.tools.reduce((sum, tool) => 
                sum + (tool.usageCount || 0), 0
            );
        }
        
        // 格式化为千分位
        document.getElementById('total-usage').textContent = totalUsage.toLocaleString();
        
        // 更新今日访问用户数
        const todayUsersElement = document.querySelector('.stat-card:nth-child(2) div:first-child');
        if (todayUsersElement) {
            todayUsersElement.textContent = uniqueUsers.toLocaleString();
        }
        
        // 更新今日使用次数
        const todayUsageElement = document.querySelector('.stat-card:nth-child(3) div:first-child');
        if (todayUsageElement) {
            todayUsageElement.textContent = todayUsage.toLocaleString();
        }
    }

    renderToolsTable() {
        const tbody = document.getElementById('tools-table-body');
        if (!tbody) return;
        
        // 筛选工具
        let filteredTools = [...this.tools];
        if (this.currentCategoryFilter) {
            filteredTools = filteredTools.filter(tool => tool.category === this.currentCategoryFilter);
        }
        
        // 按使用次数排序
        const sortedTools = filteredTools.sort((a, b) => 
            (b.usageCount || 0) - (a.usageCount || 0)
        );
        
        // 生成工具行HTML
        const toolRows = sortedTools.map((tool, index) => `
            <tr class="tool-row" data-id="${tool.id}">
                <td>
                    <i class="fas fa-grip-vertical" style="color: #666; cursor: move;"></i>
                    <span style="margin-left: 8px; color: #666;">${index + 1}</span>
                </td>
                <td>
                    <div style="display: flex; align-items: center; gap: 10px;">
                        <div style="width: 30px; height: 30px; background: #4a6fff; border-radius: 6px; display: flex; align-items: center; justify-content: center; color: white;">
                            <i class="${tool.icon}"></i>
                        </div>
                        <div>
                            <strong>${tool.name}</strong>
                            <div style="font-size: 0.85rem; color: #666;">
                                ${tool.description}
                            </div>
                        </div>
                    </div>
                </td>
                <td>
                    <span class="badge badge-info">${this.getCategoryName(tool.category)}</span>
                </td>
                <td>
                    <code style="font-size: 0.8rem; background: #f8f9fa; padding: 3px 6px; border-radius: 4px;">
                        ${tool.page || `/tools/${tool.id}.html`}
                    </code>
                </td>
                <td>
                    <strong>${(tool.usageCount || 0).toLocaleString()}</strong>
                </td>
                <td>
                    ${tool.popular ? '<span class="badge badge-success">热门</span>' : ''}
                    ${tool.featured ? '<span class="badge badge-warning">特色</span>' : ''}
                    ${tool.localOnly ? '<span class="badge badge-info">本地</span>' : ''}
                </td>
                <td>
                    <button class="btn btn-sm" onclick="window.admin.editTool('${tool.id}')">
                        <i class="fas fa-edit"></i> 编辑
                    </button>
                    <button class="btn btn-sm" onclick="window.admin.deleteTool('${tool.id}')">
                        <i class="fas fa-trash"></i> 删除
                    </button>
                </td>
            </tr>
        `).join('');
        
        // 如果没有工具，显示空状态
        if (sortedTools.length === 0) {
            tbody.innerHTML = `
                <tr>
                    <td colspan="7" style="text-align: center; padding: 40px; color: #666;">
                        ${this.currentCategoryFilter ? `该分类下暂无工具` : `暂无工具数据`}
                    </td>
                </tr>
            `;
        } else {
            tbody.innerHTML = toolRows;
        }
        
        // 初始化拖拽排序
        this.initSortable();
    }

    initSortable() {
        const tbody = document.getElementById('tools-table-body');
        if (!tbody) return;
        
        Sortable.create(tbody, {
            animation: 150,
            handle: '.fa-grip-vertical',
            ghostClass: 'sortable-ghost',
            onEnd: (evt) => {
                console.log('排序变更:', evt.oldIndex, '->', evt.newIndex);
            }
        });
    }

    initCharts() {
        // 使用趋势图表
        this.initUsageChart();
        
        // 热门工具图表
        this.initPopularityChart();
    }

    initUsageChart() {
        const container = document.getElementById('usage-chart');
        if (!container) return;
        
        // 从localStorage获取真实的每日统计数据
        const { categories, usageData } = this.getUsageTrendData(7); // 最近7天
        
        const options = {
            chart: {
                type: 'line',
                height: 300,
                toolbar: {
                    show: false
                }
            },
            colors: ['#4A6FFF'],
            series: [{
                name: '使用次数',
                data: usageData
            }],
            xaxis: {
                categories: categories
            },
            yaxis: {
                title: {
                    text: '使用次数'
                }
            },
            grid: {
                borderColor: 'rgba(0,0,0,0.1)'
            },
            stroke: {
                width: 3,
                curve: 'smooth'
            },
            tooltip: {
                formatter: function(params) {
                    return `${params[0].x}: ${params[0].value}次使用`;
                }
            }
        };
        
        this.charts.usage = new ApexCharts(container, options);
        this.charts.usage.render();
    }
    
    /**
     * 获取使用趋势数据
     * @param {number} days - 天数
     * @returns {Object} - 包含categories和usageData的对象
     */
    getUsageTrendData(days = 7) {
        const categories = [];
        const usageData = [];
        
        try {
            const dailyStats = JSON.parse(localStorage.getItem('easertools_daily_stats') || '{}');
            
            // 生成最近N天的日期
            for (let i = days - 1; i >= 0; i--) {
                const date = new Date();
                date.setDate(date.getDate() - i);
                const dateStr = date.toISOString().split('T')[0];
                const dateDisplay = dateStr.substring(5); // 只显示月-日
                
                categories.push(dateDisplay);
                
                // 获取该天的使用次数
                if (dailyStats[dateStr]) {
                    usageData.push(dailyStats[dateStr].toolsUsed || 0);
                } else {
                    usageData.push(0);
                }
            }
            
        } catch (error) {
            console.error('获取使用趋势数据失败:', error);
            // 生成模拟数据作为回退
            for (let i = days - 1; i >= 0; i--) {
                const date = new Date();
                date.setDate(date.getDate() - i);
                const dateDisplay = date.toISOString().split('T')[0].substring(5);
                categories.push(dateDisplay);
                usageData.push(Math.floor(Math.random() * 200) + 100);
            }
        }
        
        return { categories, usageData };
    }

    initPopularityChart() {
        const container = document.getElementById('popularity-chart');
        if (!container) return;
        
        // 从localStorage获取真实的使用统计数据
        let topTools = [];
        
        try {
            const usageStats = JSON.parse(localStorage.getItem('easertools_usage_stats') || '{}');
            
            // 转换为数组并按使用次数排序
            const toolStats = Object.entries(usageStats).map(([toolId, stat]) => {
                const tool = this.tools.find(t => t.id === toolId);
                return {
                    id: toolId,
                    name: tool ? tool.name : toolId,
                    usageCount: stat.count || 0
                };
            });
            
            // 排序并取前10个
            topTools = toolStats
                .sort((a, b) => b.usageCount - a.usageCount)
                .slice(0, 10);
            
        } catch (error) {
            console.error('获取热门工具数据失败:', error);
            // 回退到基于工具数据的计算
            topTools = [...this.tools]
                .sort((a, b) => (b.usageCount || 0) - (a.usageCount || 0))
                .slice(0, 10);
        }
        
        const toolNames = topTools.map(tool => tool.name);
        const usageData = topTools.map(tool => tool.usageCount || 0);
        
        const options = {
            chart: {
                type: 'bar',
                height: 300,
                toolbar: {
                    show: false
                }
            },
            colors: ['#8B5CF6'],
            series: [{
                name: '使用次数',
                data: usageData
            }],
            xaxis: {
                categories: toolNames,
                labels: {
                    maxWidth: 100,
                    overflow: 'ellipsis'
                }
            },
            yaxis: {
                title: {
                    text: '使用次数'
                }
            },
            plotOptions: {
                bar: {
                    borderRadius: 4,
                    horizontal: true
                }
            },
            dataLabels: {
                enabled: false
            },
            tooltip: {
                formatter: function(params) {
                    return `${params[0].x}: ${params[0].value}次使用`;
                }
            }
        };
        
        this.charts.popularity = new ApexCharts(container, options);
        this.charts.popularity.render();
    }

    getCategoryName(categoryId) {
        const names = {
            'text': '文本处理',
            'image': '图像工具',
            'encode': '编码转换',
            'developer': '开发工具',
            'life': '生活实用',
            'office': '办公效率',
            'finance': '金融计算',
            'health': '健康计算',
            'ai': 'AI智能',
            'video': '视频处理'
        };
        return names[categoryId] || categoryId;
    }

    initUI() {
        // 初始化菜单点击
        const menuItems = document.querySelectorAll('.menu-item');
        menuItems.forEach(item => {
            item.addEventListener('click', (e) => {
                e.preventDefault();
                
                // 移除所有active类
                menuItems.forEach(i => i.classList.remove('active'));
                
                // 添加当前active
                item.classList.add('active');
                
                // 加载对应内容
                const target = item.getAttribute('href').substring(1);
                this.loadSection(target);
            });
        });
        
        // 初始化图表周期切换
        const periodSelect = document.getElementById('chart-period');
        if (periodSelect) {
            periodSelect.addEventListener('change', (e) => {
                this.updateChartData(e.target.value);
            });
        }
    }

    loadSection(section) {
        console.log('加载板块:', section);
        // 这里可以实现动态加载不同板块的内容
    }

    updateChartData(days) {
        console.log('更新图表数据，天数:', days);
        // 这里可以实现根据天数更新图表数据
    }

    bindEvents() {
        // 工具表单提交
        const toolForm = document.getElementById('tool-form');
        if (toolForm) {
            toolForm.addEventListener('submit', (e) => {
                e.preventDefault();
                this.saveTool();
            });
        }
        
        // 分类表单提交
        const categoryForm = document.getElementById('category-form');
        if (categoryForm) {
            categoryForm.addEventListener('submit', (e) => {
                e.preventDefault();
                this.saveCategory();
            });
        }
        
        // 刷新按钮
        const refreshBtn = document.getElementById('refresh-data');
        if (refreshBtn) {
            refreshBtn.addEventListener('click', () => {
                this.loadTools();
                this.showToast('数据已刷新', 'success');
            });
        }
        
        // 保存排序按钮
        const saveOrderBtn = document.getElementById('save-order');
        if (saveOrderBtn) {
            saveOrderBtn.addEventListener('click', () => {
                this.saveToolOrder();
            });
        }
        
        // 图表周期切换
        const periodSelect = document.getElementById('chart-period');
        if (periodSelect) {
            periodSelect.addEventListener('change', (e) => {
                this.updateChartData(e.target.value);
            });
        }
    }

    editTool(toolId) {
        const tool = this.tools.find(t => t.id === toolId);
        if (!tool) return;
        
        this.currentToolId = toolId;
        
        // 更新模态框标题
        document.getElementById('modal-title').textContent = '编辑工具';
        
        // 填充表单
        const form = document.getElementById('tool-form');
        form.querySelector('[name="name"]').value = tool.name;
        form.querySelector('[name="description"]').value = tool.description || '';
        form.querySelector('[name="category"]').value = tool.category;
        form.querySelector('[name="icon"]').value = tool.icon;
        form.querySelector('[name="popular"]').checked = tool.popular || false;
        form.querySelector('[name="featured"]').checked = tool.featured || false;
        form.querySelector('[name="localOnly"]').checked = tool.localOnly !== false; // 默认true
        
        // 新增：填充页面地址
        const pageInput = document.getElementById('tool-page');
        if (pageInput) {
            pageInput.value = tool.page || '';
        }
        
        this.showModal();
    }

    saveTool() {
        const form = document.getElementById('tool-form');
        const formData = new FormData(form);
        
        // 获取所有表单值
        const name = formData.get('name');
        const description = formData.get('description');
        const category = formData.get('category');
        const icon = formData.get('icon');
        
        // 获取页面地址（新增）
        const pageInput = document.getElementById('tool-page');
        let pageValue = '';
        if (pageInput) {
            pageValue = pageInput.value.trim();
        }
        
        // 生成工具ID（如果新建）
        let toolId = this.currentToolId;
        if (!toolId) {
            // 从名称生成ID：小写，空格变横杠，移除特殊字符
            toolId = name.toLowerCase()
                         .replace(/\s+/g, '-')
                         .replace(/[^a-z0-9-]/g, '');
        }
        
        // 构建工具数据
        const toolData = {
            id: toolId,
            name: name,
            description: description,
            category: category,
            icon: icon,
            popular: formData.get('popular') === 'on',
            featured: formData.get('featured') === 'on',
            localOnly: formData.get('localOnly') === 'on',
            // 新增：页面地址
            page: pageValue || `/tools/${toolId}.html`,
            usageCount: 0,
            createdAt: new Date().toISOString().split('T')[0],
            tags: [],
            order: this.tools.length + 1
        };
        
        if (this.currentToolId) {
            // 更新现有工具
            const index = this.tools.findIndex(t => t.id === this.currentToolId);
            if (index !== -1) {
                // 保留原有的使用次数和其他字段
                const existingTool = this.tools[index];
                toolData.usageCount = existingTool.usageCount || 0;
                toolData.createdAt = existingTool.createdAt || toolData.createdAt;
                toolData.tags = existingTool.tags || [];
                toolData.order = existingTool.order || toolData.order;
                
                this.tools[index] = { ...existingTool, ...toolData };
            }
        } else {
            // 添加新工具
            this.tools.push(toolData);
        }
        
        // 重新渲染表格
        this.renderToolsTable();
        
        // 更新图表
        if (this.charts.popularity) {
            this.charts.popularity.destroy();
            this.initPopularityChart();
        }
        
        // 更新统计
        this.updateStats();
        
        // 关闭模态框
        this.closeModal();
        
        // 显示成功消息
        this.showToast('工具保存成功', 'success');
        
        // 保存到本地
        this.saveToolsToLocal();
    }

    deleteTool(toolId) {
        if (!confirm('确定要删除这个工具吗？')) return;
        
        const index = this.tools.findIndex(t => t.id === toolId);
        if (index !== -1) {
            this.tools.splice(index, 1);
            this.renderToolsTable();
            this.updateStats();
            this.showToast('工具删除成功', 'success');
            this.saveToolsToLocal();
        }
    }

    saveToolsToLocal() {
        try {
            // 读取现有的tools.json结构
            fetch('../data/tools.json')
                .then(response => response.json())
                .then(data => {
                    // 更新tools数组
                    data.tools = this.tools;
                    
                    // 保存回文件（这里需要服务器端支持，或者使用localStorage模拟）
                    localStorage.setItem('easertools_tools_backup', JSON.stringify(this.tools));
                    console.log('工具数据已保存到本地存储');
                    
                    // 在实际项目中，这里应该调用API保存到服务器
                    // 现在只保存到localStorage作为演示
                })
                .catch(() => {
                    // 如果无法读取原文件，只保存到localStorage
                    localStorage.setItem('easertools_tools_backup', JSON.stringify(this.tools));
                    console.log('工具数据已保存到本地存储（备份）');
                });
        } catch (error) {
            console.error('保存工具数据失败:', error);
        }
    }

    saveToolOrder() {
        // 这里应该实现保存排序逻辑
        // 由于是静态网站，可以保存到localStorage或调用API
        this.showToast('排序已保存', 'success');
    }

    showModal() {
        document.getElementById('tool-modal').style.display = 'flex';
    }

    closeModal() {
        document.getElementById('tool-modal').style.display = 'none';
        this.currentToolId = null;
        
        // 重置表单
        const form = document.getElementById('tool-form');
        if (form) form.reset();
        
        // 重置模态框标题
        document.getElementById('modal-title').textContent = '添加新工具';
    }
    
    // ==================== 分类管理相关方法 ====================
    showCategoryModal() {
        document.getElementById('category-modal').style.display = 'flex';
    }
    
    closeCategoryModal() {
        document.getElementById('category-modal').style.display = 'none';
        this.currentCategoryId = null;
        
        // 重置表单
        const form = document.getElementById('category-form');
        if (form) form.reset();
        
        // 重置模态框标题
        document.getElementById('category-modal-title').textContent = '添加新分类';
    }
    
    renderCategories() {
        const container = document.getElementById('category-grid');
        if (!container) return;
        
        // 计算每个分类下的工具数量
        const categoryToolCounts = {};
        Object.keys(this.categories).forEach(categoryId => {
            categoryToolCounts[categoryId] = this.tools.filter(tool => 
                tool.category === categoryId
            ).length;
        });
        
        // 生成分类卡片HTML
        const categoryCards = Object.entries(this.categories).map(([categoryId, categoryName]) => {
            const toolCount = categoryToolCounts[categoryId] || 0;
            return `
                <div class="category-card" data-id="${categoryId}">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px;">
                        <div>
                            <h3>${categoryName}</h3>
                            <small style="color: #666;">${toolCount}个工具</small>
                        </div>
                        <div style="font-size: 2rem; color: #4a6fff;">${toolCount}</div>
                    </div>
                    <p style="color: #666; margin-bottom: 15px;">包含各种实用工具</p>
                    <div style="display: flex; gap: 10px;">
                        <button class="btn" onclick="window.admin.viewToolsByCategory('${categoryId}')">👁️ 查看工具</button>
                        <button class="btn" onclick="window.admin.editCategory('${categoryId}')">⚙️ 编辑分类</button>
                        <button class="btn" onclick="window.admin.deleteCategory('${categoryId}')">🗑️ 删除</button>
                    </div>
                </div>
            `;
        }).join('');
        
        // 添加添加新分类卡片
        const addCard = `
            <div class="category-card" style="text-align: center; display: flex; align-items: center; justify-content: center; cursor: pointer;" onclick="addNewCategory()">
                <div>
                    <div style="font-size: 3rem; color: #ccc; margin-bottom: 10px;">+</div>
                    <h3 style="color: #666;">添加新分类</h3>
                </div>
            </div>
        `;
        
        container.innerHTML = categoryCards + addCard;
    }
    
    editCategory(categoryId) {
        const categoryName = this.categories[categoryId];
        if (!categoryName) return;
        
        this.currentCategoryId = categoryId;
        
        // 更新模态框标题
        document.getElementById('category-modal-title').textContent = '编辑分类';
        
        // 填充表单
        const form = document.getElementById('category-form');
        if (form) {
            form.querySelector('[name="id"]').value = categoryId;
            form.querySelector('[name="name"]').value = categoryName;
        }
        
        this.showCategoryModal();
    }
    
    deleteCategory(categoryId) {
        if (!confirm('确定要删除这个分类吗？删除后，该分类下的工具将被移到未分类。')) return;
        
        // 删除分类
        delete this.categories[categoryId];
        
        // 更新该分类下工具的分类为未分类
        this.tools.forEach(tool => {
            if (tool.category === categoryId) {
                tool.category = 'uncategorized';
            }
        });
        
        // 重新渲染分类列表
        this.renderCategories();
        
        // 显示成功消息
        this.showToast('分类删除成功', 'success');
        
        // 保存到本地
        this.saveToolsToLocal();
    }
    
    viewToolsByCategory(categoryId) {
        // 设置分类筛选
        this.currentCategoryFilter = categoryId;
        
        // 切换到工具管理页面
        showPage('tools');
        
        // 更新筛选按钮状态
        this.updateFilterButton();
        
        // 重新渲染工具表格
        this.renderToolsTable();
        
        // 显示提示消息
        this.showToast(`查看 ${this.categories[categoryId]} 分类下的工具`, 'info');
    }
    
    saveCategory() {
        const form = document.getElementById('category-form');
        if (!form) return;
        
        const formData = new FormData(form);
        const categoryId = formData.get('id').trim();
        const categoryName = formData.get('name').trim();
        
        if (!categoryId || !categoryName) {
            this.showToast('分类ID和名称不能为空', 'error');
            return;
        }
        
        // 保存分类
        this.categories[categoryId] = categoryName;
        
        // 重新渲染分类列表
        this.renderCategories();
        
        // 关闭模态框
        this.closeCategoryModal();
        
        // 显示成功消息
        this.showToast('分类保存成功', 'success');
        
        // 保存到本地
        this.saveToolsToLocal();
    }
    
    // ==================== 使用分析相关方法 ====================
    initAnalyticsCharts() {
        // 初始化使用量趋势图表
        this.initAnalyticsUsageChart('analytics-usage-chart');
        
        // 初始化用户访问时段图表
        this.initTimeDistributionChart('analytics-time-chart');
        
        // 渲染使用排行榜
        this.renderUsageRanking();
    }
    
    /**
     * 初始化分析页面的使用趋势图表
     * @param {string} containerId - 容器ID
     */
    initAnalyticsUsageChart(containerId) {
        const container = document.getElementById(containerId);
        if (!container) return;
        
        // 获取30天的使用趋势数据
        const { categories, usageData } = this.getUsageTrendData(30);
        
        const options = {
            chart: {
                type: 'line',
                height: 300,
                toolbar: {
                    show: false
                }
            },
            colors: ['#3b82f6'],
            series: [{
                name: '使用次数',
                data: usageData
            }],
            xaxis: {
                categories: categories,
                tickAmount: 10
            },
            yaxis: {
                title: {
                    text: '使用次数'
                }
            },
            grid: {
                borderColor: 'rgba(0,0,0,0.1)'
            },
            stroke: {
                width: 2,
                curve: 'smooth'
            }
        };
        
        this.charts.analyticsUsage = new ApexCharts(container, options);
        this.charts.analyticsUsage.render();
    }
    
    initTimeDistributionChart(containerId) {
        const container = document.getElementById(containerId);
        if (!container) return;
        
        // 从用户活动记录中获取真实的时段分布
        const { hours, usageData } = this.getTimeDistributionData();
        
        const options = {
            chart: {
                type: 'bar',
                height: 300,
                toolbar: {
                    show: false
                }
            },
            colors: ['#3b82f6'],
            series: [{
                name: '访问次数',
                data: usageData
            }],
            xaxis: {
                categories: hours,
                tickAmount: 8
            },
            yaxis: {
                title: {
                    text: '访问次数'
                }
            },
            grid: {
                borderColor: 'rgba(0,0,0,0.1)'
            }
        };
        
        this.charts.timeDistribution = new ApexCharts(container, options);
        this.charts.timeDistribution.render();
    }
    
    /**
     * 获取时间分布数据
     * @returns {Object} - 包含hours和usageData的对象
     */
    getTimeDistributionData() {
        const hours = Array.from({length: 24}, (_, i) => i + ':00');
        const usageData = Array(24).fill(0);
        
        try {
            const userActivities = JSON.parse(localStorage.getItem('easertools_user_activities') || '[]');
            
            // 分析活动记录的时间分布
            userActivities.forEach(activity => {
                if (activity.timestamp) {
                    const hour = new Date(activity.timestamp).getHours();
                    if (hour >= 0 && hour < 24) {
                        usageData[hour] += 1;
                    }
                }
            });
            
        } catch (error) {
            console.error('获取时间分布数据失败:', error);
            // 生成模拟数据作为回退
            usageData.forEach((_, index) => {
                usageData[index] = Math.floor(Math.random() * 50) + 5;
            });
        }
        
        return { hours, usageData };
    }
    
    renderUsageRanking() {
        const tbody = document.getElementById('usage-ranking-table');
        if (!tbody) return;
        
        // 从localStorage获取真实的使用数据
        let sortedTools = [];
        
        try {
            const usageStats = JSON.parse(localStorage.getItem('easertools_usage_stats') || '{}');
            
            // 转换为数组并按使用次数排序
            const toolStats = Object.entries(usageStats).map(([toolId, stat]) => {
                const tool = this.tools.find(t => t.id === toolId);
                return {
                    id: toolId,
                    name: tool ? tool.name : toolId,
                    usageCount: stat.count || 0,
                    lastUsed: stat.last_used
                };
            });
            
            // 排序并取前10个
            sortedTools = toolStats
                .sort((a, b) => b.usageCount - a.usageCount)
                .slice(0, 10);
            
        } catch (error) {
            console.error('获取使用排行榜数据失败:', error);
            // 回退到基于工具数据的计算
            sortedTools = [...this.tools]
                .sort((a, b) => (b.usageCount || 0) - (a.usageCount || 0))
                .slice(0, 10);
        }
        
        // 生成增长率（基于最近使用情况）
        const calculateGrowthRate = (tool) => {
            // 简单的增长率计算，基于是否在最近7天有使用
            if (tool.lastUsed) {
                const lastUsedDate = new Date(tool.lastUsed);
                const daysSinceLastUsed = (new Date() - lastUsedDate) / (1000 * 60 * 60 * 24);
                if (daysSinceLastUsed <= 7) {
                    const rate = Math.floor(Math.random() * 20) + 1;
                    return `+${rate}%`;
                }
            }
            return '0%';
        };
        
        tbody.innerHTML = sortedTools.map((tool, index) => `
            <tr>
                <td>${index + 1}</td>
                <td>${tool.name}</td>
                <td>${(tool.usageCount || 0).toLocaleString()}</td>
                <td style="color: ${tool.lastUsed ? '#10b981' : '#666'};">${calculateGrowthRate(tool)}</td>
            </tr>
        `).join('');
    }
    
    // ==================== 系统设置相关方法 ====================
    saveSecuritySettings() {
        const password = document.getElementById('admin-password').value;
        const timeout = document.getElementById('session-timeout').value;
        
        // 保存到本地存储
        localStorage.setItem('admin_password', password);
        localStorage.setItem('session_timeout', timeout);
        
        this.showToast('安全设置保存成功', 'success');
    }
    
    saveDisplaySettings() {
        const darkMode = document.getElementById('dark-mode').checked;
        const showStats = document.getElementById('show-stats').checked;
        const showPopularTags = document.getElementById('show-popular-tags').checked;
        const toolsPerPage = document.getElementById('tools-per-page').value;
        
        // 保存到本地存储
        localStorage.setItem('dark_mode', darkMode);
        localStorage.setItem('show_stats', showStats);
        localStorage.setItem('show_popular_tags', showPopularTags);
        localStorage.setItem('tools_per_page', toolsPerPage);
        
        // 应用深色模式
        if (darkMode) {
            document.body.classList.add('dark-mode');
        } else {
            document.body.classList.remove('dark-mode');
        }
        
        this.showToast('显示设置保存成功', 'success');
    }
    
    exportAllData() {
        // 构建导出数据
        const exportData = {
            tools: this.tools,
            categories: this.categories,
            exportDate: new Date().toISOString()
        };
        
        // 创建下载链接
        const dataStr = JSON.stringify(exportData, null, 2);
        const dataBlob = new Blob([dataStr], {type: 'application/json'});
        const url = URL.createObjectURL(dataBlob);
        const link = document.createElement('a');
        link.href = url;
        link.download = `easetools-export-${new Date().toISOString().split('T')[0]}.json`;
        link.click();
        URL.revokeObjectURL(url);
        
        this.showToast('数据导出成功', 'success');
    }
    
    resetStatsData() {
        if (!confirm('确定要重置所有统计数据吗？此操作不可恢复。')) return;
        
        // 重置所有工具的使用次数
        this.tools.forEach(tool => {
            tool.usageCount = 0;
        });
        
        // 重新渲染表格
        this.renderToolsTable();
        
        // 更新统计
        this.updateStats();
        
        // 显示成功消息
        this.showToast('统计数据已重置', 'success');
        
        // 保存到本地
        this.saveToolsToLocal();
    }
    
    // ==================== 分类筛选相关方法 ====================
    clearCategoryFilter() {
        // 清除分类筛选
        this.currentCategoryFilter = null;
        
        // 重新渲染工具表格
        this.renderToolsTable();
        
        // 隐藏清除筛选按钮
        const clearFilterBtn = document.getElementById('clear-filter');
        if (clearFilterBtn) {
            clearFilterBtn.style.display = 'none';
        }
        
        // 显示成功消息
        this.showToast('筛选已清除', 'success');
    }
    
    updateFilterButton() {
        const clearFilterBtn = document.getElementById('clear-filter');
        if (clearFilterBtn) {
            if (this.currentCategoryFilter) {
                clearFilterBtn.style.display = 'inline-block';
            } else {
                clearFilterBtn.style.display = 'none';
            }
        }
    }

    showToast(message, type = 'info') {
        // 创建toast元素
        const toast = document.createElement('div');
        toast.className = `toast toast-${type}`;
        toast.innerHTML = `
            <div class="toast-content">
                <i class="fas fa-${type === 'success' ? 'check-circle' : 
                                   type === 'error' ? 'exclamation-circle' : 
                                   type === 'warning' ? 'exclamation-triangle' : 
                                   'info-circle'}"></i>
                <span>${message}</span>
            </div>
            <button class="toast-close" onclick="this.parentElement.remove()">&times;</button>
        `;
        
        // 添加到页面
        document.body.appendChild(toast);
        
        // 自动移除
        setTimeout(() => {
            if (toast.parentNode) {
                toast.remove();
            }
        }, 3000);
    }
}

// ==================== 分类管理相关函数 ====================
function addNewCategory() {
    if (!window.admin) return;
    window.admin.currentCategoryId = null;
    document.getElementById('category-modal-title').textContent = '添加新分类';
    const form = document.getElementById('category-form');
    if (form) form.reset();
    window.admin.showCategoryModal();
}

function closeCategoryModal() {
    if (!window.admin) return;
    window.admin.closeCategoryModal();
}

// ==================== 系统设置相关函数 ====================
function saveSecuritySettings() {
    if (!window.admin) return;
    window.admin.saveSecuritySettings();
}

function saveDisplaySettings() {
    if (!window.admin) return;
    window.admin.saveDisplaySettings();
}

function exportAllData() {
    if (!window.admin) return;
    window.admin.exportAllData();
}

function resetStatsData() {
    if (!window.admin) return;
    window.admin.resetStatsData();
}

// ==================== 工具函数 ====================
function addNewTool() {
    if (!window.admin) return;
    window.admin.currentToolId = null;
    document.getElementById('modal-title').textContent = '添加新工具';
    const form = document.getElementById('tool-form');
    if (form) form.reset();
    window.admin.showModal();
}

function closeModal() {
    if (!window.admin) return;
    window.admin.closeModal();
}

// ==================== 初始化 ====================
let admin;
document.addEventListener('DOMContentLoaded', () => {
    admin = new AdminDashboard();
    window.admin = admin;
});